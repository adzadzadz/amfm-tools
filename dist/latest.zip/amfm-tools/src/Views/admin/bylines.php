<?php
if (!defined('ABSPATH')) exit;
?>

<div id="flash-message-container"></div>

<!-- Staff CPT Management - Full Width -->
<?php include plugin_dir_path(__FILE__) . 'components/bylines-cpt-enabled.php'; ?>

